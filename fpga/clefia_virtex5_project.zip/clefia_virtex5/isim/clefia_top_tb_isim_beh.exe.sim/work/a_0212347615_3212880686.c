/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/joaocarlos/workspace/fpga/clefia-full-key-expansion/rtl/cipher/cipher_datapath.vhd";
extern char *IEEE_P_2592010699;

char *ieee_p_2592010699_sub_16439989833707593767_503743352(char *, char *, char *, char *, char *, char *);


static void work_a_0212347615_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(100, ng0);
    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB3;

LAB4:
LAB5:    t10 = (t0 + 5992U);
    t11 = *((char **)t10);
    t10 = (t0 + 12144);
    t12 = (t10 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t11, 32U);
    xsi_driver_first_trans_fast(t10);

LAB2:    t16 = (t0 + 11824);
    *((int *)t16) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 1032U);
    t5 = *((char **)t1);
    t1 = (t0 + 12144);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 32U);
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_0212347615_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(103, ng0);
    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB3;

LAB4:
LAB5:    t10 = (t0 + 3592U);
    t11 = *((char **)t10);
    t10 = (t0 + 12208);
    t12 = (t10 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t11, 32U);
    xsi_driver_first_trans_fast(t10);

LAB2:    t16 = (t0 + 11840);
    *((int *)t16) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 4552U);
    t5 = *((char **)t1);
    t1 = (t0 + 12208);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 32U);
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_0212347615_3212880686_p_2(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(106, ng0);

LAB3:    t2 = (t0 + 3752U);
    t3 = *((char **)t2);
    t2 = (t0 + 20584U);
    t4 = (t0 + 3912U);
    t5 = *((char **)t4);
    t4 = (t0 + 20584U);
    t6 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t1, t3, t2, t5, t4);
    t7 = (t1 + 12U);
    t8 = *((unsigned int *)t7);
    t9 = (1U * t8);
    t10 = (32U != t9);
    if (t10 == 1)
        goto LAB5;

LAB6:    t11 = (t0 + 12272);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast(t11);

LAB2:    t16 = (t0 + 11856);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(32U, t9, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_3(char *t0)
{
    char t5[16];
    char t19[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned char t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    xsi_set_current_line(124, ng0);
    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB3;

LAB4:
LAB7:    t20 = (t0 + 3592U);
    t21 = *((char **)t20);
    t20 = (t0 + 20584U);
    t22 = (t0 + 5992U);
    t23 = *((char **)t22);
    t22 = (t0 + 20664U);
    t24 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t19, t21, t20, t23, t22);
    t25 = (t19 + 12U);
    t26 = *((unsigned int *)t25);
    t27 = (1U * t26);
    t28 = (32U != t27);
    if (t28 == 1)
        goto LAB9;

LAB10:    t29 = (t0 + 12336);
    t30 = (t29 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    memcpy(t33, t24, 32U);
    xsi_driver_first_trans_fast(t29);

LAB2:    t34 = (t0 + 11872);
    *((int *)t34) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 4552U);
    t6 = *((char **)t1);
    t1 = (t0 + 20616U);
    t7 = (t0 + 5992U);
    t8 = *((char **)t7);
    t7 = (t0 + 20664U);
    t9 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t5, t6, t1, t8, t7);
    t10 = (t5 + 12U);
    t11 = *((unsigned int *)t10);
    t12 = (1U * t11);
    t13 = (32U != t12);
    if (t13 == 1)
        goto LAB5;

LAB6:    t14 = (t0 + 12336);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t9, 32U);
    xsi_driver_first_trans_fast(t14);
    goto LAB2;

LAB5:    xsi_size_not_matching(32U, t12, 0);
    goto LAB6;

LAB8:    goto LAB2;

LAB9:    xsi_size_not_matching(32U, t27, 0);
    goto LAB10;

}

static void work_a_0212347615_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(128, ng0);
    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB3;

LAB4:
LAB5:    t10 = (t0 + 3272U);
    t11 = *((char **)t10);
    t10 = (t0 + 12400);
    t12 = (t10 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t11, 32U);
    xsi_driver_first_trans_fast(t10);

LAB2:    t16 = (t0 + 11888);
    *((int *)t16) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 5992U);
    t5 = *((char **)t1);
    t1 = (t0 + 12400);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 32U);
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_0212347615_3212880686_p_5(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(133, ng0);

LAB3:    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t2 = (t0 + 20584U);
    t4 = (t0 + 1352U);
    t5 = *((char **)t4);
    t4 = (t0 + 20520U);
    t6 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t1, t3, t2, t5, t4);
    t7 = (t1 + 12U);
    t8 = *((unsigned int *)t7);
    t9 = (1U * t8);
    t10 = (32U != t9);
    if (t10 == 1)
        goto LAB5;

LAB6:    t11 = (t0 + 12464);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast(t11);

LAB2:    t16 = (t0 + 11904);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(32U, t9, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_6(char *t0)
{
    char t9[16];
    char t11[16];
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t8;
    char *t10;
    char *t12;
    char *t13;
    int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(138, ng0);

LAB3:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 3432U);
    t4 = *((char **)t1);
    t5 = (31 - 31);
    t6 = (t5 * 1U);
    t7 = (0 + t6);
    t1 = (t4 + t7);
    t10 = ((IEEE_P_2592010699) + 4000);
    t12 = (t11 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = 31;
    t13 = (t12 + 4U);
    *((int *)t13) = 24;
    t13 = (t12 + 8U);
    *((int *)t13) = -1;
    t14 = (24 - 31);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t8 = xsi_base_array_concat(t8, t9, t10, (char)99, t3, (char)97, t1, t11, (char)101);
    t15 = (1U + 8U);
    t16 = (9U != t15);
    if (t16 == 1)
        goto LAB5;

LAB6:    t13 = (t0 + 12528);
    t17 = (t13 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t8, 9U);
    xsi_driver_first_trans_fast(t13);

LAB2:    t21 = (t0 + 11920);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(9U, t15, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_7(char *t0)
{
    char t9[16];
    char t11[16];
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t8;
    char *t10;
    char *t12;
    char *t13;
    int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(139, ng0);

LAB3:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 3432U);
    t4 = *((char **)t1);
    t5 = (31 - 23);
    t6 = (t5 * 1U);
    t7 = (0 + t6);
    t1 = (t4 + t7);
    t10 = ((IEEE_P_2592010699) + 4000);
    t12 = (t11 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = 23;
    t13 = (t12 + 4U);
    *((int *)t13) = 16;
    t13 = (t12 + 8U);
    *((int *)t13) = -1;
    t14 = (16 - 23);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t8 = xsi_base_array_concat(t8, t9, t10, (char)99, t3, (char)97, t1, t11, (char)101);
    t15 = (1U + 8U);
    t16 = (9U != t15);
    if (t16 == 1)
        goto LAB5;

LAB6:    t13 = (t0 + 12592);
    t17 = (t13 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t8, 9U);
    xsi_driver_first_trans_fast(t13);

LAB2:    t21 = (t0 + 11936);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(9U, t15, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_8(char *t0)
{
    char t9[16];
    char t11[16];
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t8;
    char *t10;
    char *t12;
    char *t13;
    int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(140, ng0);

LAB3:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 3432U);
    t4 = *((char **)t1);
    t5 = (31 - 15);
    t6 = (t5 * 1U);
    t7 = (0 + t6);
    t1 = (t4 + t7);
    t10 = ((IEEE_P_2592010699) + 4000);
    t12 = (t11 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = 15;
    t13 = (t12 + 4U);
    *((int *)t13) = 8;
    t13 = (t12 + 8U);
    *((int *)t13) = -1;
    t14 = (8 - 15);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t8 = xsi_base_array_concat(t8, t9, t10, (char)99, t3, (char)97, t1, t11, (char)101);
    t15 = (1U + 8U);
    t16 = (9U != t15);
    if (t16 == 1)
        goto LAB5;

LAB6:    t13 = (t0 + 12656);
    t17 = (t13 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t8, 9U);
    xsi_driver_first_trans_fast(t13);

LAB2:    t21 = (t0 + 11952);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(9U, t15, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_9(char *t0)
{
    char t9[16];
    char t11[16];
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t8;
    char *t10;
    char *t12;
    char *t13;
    int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(141, ng0);

LAB3:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 3432U);
    t4 = *((char **)t1);
    t5 = (31 - 7);
    t6 = (t5 * 1U);
    t7 = (0 + t6);
    t1 = (t4 + t7);
    t10 = ((IEEE_P_2592010699) + 4000);
    t12 = (t11 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = 7;
    t13 = (t12 + 4U);
    *((int *)t13) = 0;
    t13 = (t12 + 8U);
    *((int *)t13) = -1;
    t14 = (0 - 7);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t8 = xsi_base_array_concat(t8, t9, t10, (char)99, t3, (char)97, t1, t11, (char)101);
    t15 = (1U + 8U);
    t16 = (9U != t15);
    if (t16 == 1)
        goto LAB5;

LAB6:    t13 = (t0 + 12720);
    t17 = (t13 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t8, 9U);
    xsi_driver_first_trans_fast(t13);

LAB2:    t21 = (t0 + 11968);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(9U, t15, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_10(char *t0)
{
    char t1[16];
    char t2[16];
    char t8[16];
    char t16[16];
    char t21[16];
    char t26[16];
    char t34[16];
    char *t3;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t9;
    char *t10;
    int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    char *t27;
    char *t28;
    int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned char t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;

LAB0:    xsi_set_current_line(164, ng0);

LAB3:    t3 = (t0 + 5352U);
    t4 = *((char **)t3);
    t5 = (31 - 31);
    t6 = (t5 * 1U);
    t7 = (0 + t6);
    t3 = (t4 + t7);
    t9 = (t8 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 31;
    t10 = (t9 + 4U);
    *((int *)t10) = 24;
    t10 = (t9 + 8U);
    *((int *)t10) = -1;
    t11 = (24 - 31);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t12;
    t10 = (t0 + 5672U);
    t13 = *((char **)t10);
    t12 = (31 - 15);
    t14 = (t12 * 1U);
    t15 = (0 + t14);
    t10 = (t13 + t15);
    t17 = (t16 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 15;
    t18 = (t17 + 4U);
    *((int *)t18) = 8;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (8 - 15);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t2, t3, t8, t10, t16);
    t22 = (t0 + 5512U);
    t23 = *((char **)t22);
    t20 = (31 - 31);
    t24 = (t20 * 1U);
    t25 = (0 + t24);
    t22 = (t23 + t25);
    t27 = (t26 + 0U);
    t28 = (t27 + 0U);
    *((int *)t28) = 31;
    t28 = (t27 + 4U);
    *((int *)t28) = 24;
    t28 = (t27 + 8U);
    *((int *)t28) = -1;
    t29 = (24 - 31);
    t30 = (t29 * -1);
    t30 = (t30 + 1);
    t28 = (t27 + 12U);
    *((unsigned int *)t28) = t30;
    t28 = (t0 + 5832U);
    t31 = *((char **)t28);
    t30 = (31 - 15);
    t32 = (t30 * 1U);
    t33 = (0 + t32);
    t28 = (t31 + t33);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 15;
    t36 = (t35 + 4U);
    *((int *)t36) = 8;
    t36 = (t35 + 8U);
    *((int *)t36) = -1;
    t37 = (8 - 15);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t36 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t21, t22, t26, t28, t34);
    t39 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t1, t18, t2, t36, t21);
    t40 = (t1 + 12U);
    t38 = *((unsigned int *)t40);
    t41 = (1U * t38);
    t42 = (8U != t41);
    if (t42 == 1)
        goto LAB5;

LAB6:    t43 = (t0 + 12784);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    t46 = (t45 + 56U);
    t47 = *((char **)t46);
    memcpy(t47, t39, 8U);
    xsi_driver_first_trans_delta(t43, 0U, 8U, 0LL);

LAB2:    t48 = (t0 + 11984);
    *((int *)t48) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t41, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_11(char *t0)
{
    char t1[16];
    char t2[16];
    char t8[16];
    char t16[16];
    char t21[16];
    char t26[16];
    char t34[16];
    char *t3;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t9;
    char *t10;
    int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    char *t27;
    char *t28;
    int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned char t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;

LAB0:    xsi_set_current_line(166, ng0);

LAB3:    t3 = (t0 + 5352U);
    t4 = *((char **)t3);
    t5 = (31 - 23);
    t6 = (t5 * 1U);
    t7 = (0 + t6);
    t3 = (t4 + t7);
    t9 = (t8 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 23;
    t10 = (t9 + 4U);
    *((int *)t10) = 16;
    t10 = (t9 + 8U);
    *((int *)t10) = -1;
    t11 = (16 - 23);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t12;
    t10 = (t0 + 5672U);
    t13 = *((char **)t10);
    t12 = (31 - 7);
    t14 = (t12 * 1U);
    t15 = (0 + t14);
    t10 = (t13 + t15);
    t17 = (t16 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 7;
    t18 = (t17 + 4U);
    *((int *)t18) = 0;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (0 - 7);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t2, t3, t8, t10, t16);
    t22 = (t0 + 5512U);
    t23 = *((char **)t22);
    t20 = (31 - 23);
    t24 = (t20 * 1U);
    t25 = (0 + t24);
    t22 = (t23 + t25);
    t27 = (t26 + 0U);
    t28 = (t27 + 0U);
    *((int *)t28) = 23;
    t28 = (t27 + 4U);
    *((int *)t28) = 16;
    t28 = (t27 + 8U);
    *((int *)t28) = -1;
    t29 = (16 - 23);
    t30 = (t29 * -1);
    t30 = (t30 + 1);
    t28 = (t27 + 12U);
    *((unsigned int *)t28) = t30;
    t28 = (t0 + 5832U);
    t31 = *((char **)t28);
    t30 = (31 - 7);
    t32 = (t30 * 1U);
    t33 = (0 + t32);
    t28 = (t31 + t33);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 7;
    t36 = (t35 + 4U);
    *((int *)t36) = 0;
    t36 = (t35 + 8U);
    *((int *)t36) = -1;
    t37 = (0 - 7);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t36 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t21, t22, t26, t28, t34);
    t39 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t1, t18, t2, t36, t21);
    t40 = (t1 + 12U);
    t38 = *((unsigned int *)t40);
    t41 = (1U * t38);
    t42 = (8U != t41);
    if (t42 == 1)
        goto LAB5;

LAB6:    t43 = (t0 + 12848);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    t46 = (t45 + 56U);
    t47 = *((char **)t46);
    memcpy(t47, t39, 8U);
    xsi_driver_first_trans_delta(t43, 8U, 8U, 0LL);

LAB2:    t48 = (t0 + 12000);
    *((int *)t48) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t41, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_12(char *t0)
{
    char t1[16];
    char t2[16];
    char t8[16];
    char t16[16];
    char t21[16];
    char t26[16];
    char t34[16];
    char *t3;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t9;
    char *t10;
    int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    char *t27;
    char *t28;
    int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned char t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;

LAB0:    xsi_set_current_line(168, ng0);

LAB3:    t3 = (t0 + 5352U);
    t4 = *((char **)t3);
    t5 = (31 - 15);
    t6 = (t5 * 1U);
    t7 = (0 + t6);
    t3 = (t4 + t7);
    t9 = (t8 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 15;
    t10 = (t9 + 4U);
    *((int *)t10) = 8;
    t10 = (t9 + 8U);
    *((int *)t10) = -1;
    t11 = (8 - 15);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t12;
    t10 = (t0 + 5672U);
    t13 = *((char **)t10);
    t12 = (31 - 31);
    t14 = (t12 * 1U);
    t15 = (0 + t14);
    t10 = (t13 + t15);
    t17 = (t16 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 31;
    t18 = (t17 + 4U);
    *((int *)t18) = 24;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (24 - 31);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t2, t3, t8, t10, t16);
    t22 = (t0 + 5512U);
    t23 = *((char **)t22);
    t20 = (31 - 15);
    t24 = (t20 * 1U);
    t25 = (0 + t24);
    t22 = (t23 + t25);
    t27 = (t26 + 0U);
    t28 = (t27 + 0U);
    *((int *)t28) = 15;
    t28 = (t27 + 4U);
    *((int *)t28) = 8;
    t28 = (t27 + 8U);
    *((int *)t28) = -1;
    t29 = (8 - 15);
    t30 = (t29 * -1);
    t30 = (t30 + 1);
    t28 = (t27 + 12U);
    *((unsigned int *)t28) = t30;
    t28 = (t0 + 5832U);
    t31 = *((char **)t28);
    t30 = (31 - 31);
    t32 = (t30 * 1U);
    t33 = (0 + t32);
    t28 = (t31 + t33);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 31;
    t36 = (t35 + 4U);
    *((int *)t36) = 24;
    t36 = (t35 + 8U);
    *((int *)t36) = -1;
    t37 = (24 - 31);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t36 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t21, t22, t26, t28, t34);
    t39 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t1, t18, t2, t36, t21);
    t40 = (t1 + 12U);
    t38 = *((unsigned int *)t40);
    t41 = (1U * t38);
    t42 = (8U != t41);
    if (t42 == 1)
        goto LAB5;

LAB6:    t43 = (t0 + 12912);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    t46 = (t45 + 56U);
    t47 = *((char **)t46);
    memcpy(t47, t39, 8U);
    xsi_driver_first_trans_delta(t43, 16U, 8U, 0LL);

LAB2:    t48 = (t0 + 12016);
    *((int *)t48) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t41, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_13(char *t0)
{
    char t1[16];
    char t2[16];
    char t8[16];
    char t16[16];
    char t21[16];
    char t26[16];
    char t34[16];
    char *t3;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t9;
    char *t10;
    int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    char *t27;
    char *t28;
    int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned char t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;

LAB0:    xsi_set_current_line(170, ng0);

LAB3:    t3 = (t0 + 5352U);
    t4 = *((char **)t3);
    t5 = (31 - 7);
    t6 = (t5 * 1U);
    t7 = (0 + t6);
    t3 = (t4 + t7);
    t9 = (t8 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 7;
    t10 = (t9 + 4U);
    *((int *)t10) = 0;
    t10 = (t9 + 8U);
    *((int *)t10) = -1;
    t11 = (0 - 7);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t12;
    t10 = (t0 + 5672U);
    t13 = *((char **)t10);
    t12 = (31 - 23);
    t14 = (t12 * 1U);
    t15 = (0 + t14);
    t10 = (t13 + t15);
    t17 = (t16 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 23;
    t18 = (t17 + 4U);
    *((int *)t18) = 16;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (16 - 23);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t2, t3, t8, t10, t16);
    t22 = (t0 + 5512U);
    t23 = *((char **)t22);
    t20 = (31 - 7);
    t24 = (t20 * 1U);
    t25 = (0 + t24);
    t22 = (t23 + t25);
    t27 = (t26 + 0U);
    t28 = (t27 + 0U);
    *((int *)t28) = 7;
    t28 = (t27 + 4U);
    *((int *)t28) = 0;
    t28 = (t27 + 8U);
    *((int *)t28) = -1;
    t29 = (0 - 7);
    t30 = (t29 * -1);
    t30 = (t30 + 1);
    t28 = (t27 + 12U);
    *((unsigned int *)t28) = t30;
    t28 = (t0 + 5832U);
    t31 = *((char **)t28);
    t30 = (31 - 23);
    t32 = (t30 * 1U);
    t33 = (0 + t32);
    t28 = (t31 + t33);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 23;
    t36 = (t35 + 4U);
    *((int *)t36) = 16;
    t36 = (t35 + 8U);
    *((int *)t36) = -1;
    t37 = (16 - 23);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t36 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t21, t22, t26, t28, t34);
    t39 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t1, t18, t2, t36, t21);
    t40 = (t1 + 12U);
    t38 = *((unsigned int *)t40);
    t41 = (1U * t38);
    t42 = (8U != t41);
    if (t42 == 1)
        goto LAB5;

LAB6:    t43 = (t0 + 12976);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    t46 = (t45 + 56U);
    t47 = *((char **)t46);
    memcpy(t47, t39, 8U);
    xsi_driver_first_trans_delta(t43, 24U, 8U, 0LL);

LAB2:    t48 = (t0 + 12032);
    *((int *)t48) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t41, 0);
    goto LAB6;

}

static void work_a_0212347615_3212880686_p_14(char *t0)
{
    char t5[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    xsi_set_current_line(175, ng0);
    t1 = (t0 + 2152U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB3;

LAB4:
LAB7:    t19 = (t0 + 1192U);
    t20 = *((char **)t19);
    t19 = (t0 + 13040);
    t21 = (t19 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t20, 32U);
    xsi_driver_first_trans_fast(t19);

LAB2:    t25 = (t0 + 12048);
    *((int *)t25) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 4232U);
    t6 = *((char **)t1);
    t1 = (t0 + 20600U);
    t7 = (t0 + 1192U);
    t8 = *((char **)t7);
    t7 = (t0 + 20504U);
    t9 = ieee_p_2592010699_sub_16439989833707593767_503743352(IEEE_P_2592010699, t5, t6, t1, t8, t7);
    t10 = (t5 + 12U);
    t11 = *((unsigned int *)t10);
    t12 = (1U * t11);
    t13 = (32U != t12);
    if (t13 == 1)
        goto LAB5;

LAB6:    t14 = (t0 + 13040);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t9, 32U);
    xsi_driver_first_trans_fast(t14);
    goto LAB2;

LAB5:    xsi_size_not_matching(32U, t12, 0);
    goto LAB6;

LAB8:    goto LAB2;

}

static void work_a_0212347615_3212880686_p_15(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(199, ng0);

LAB3:    t1 = (t0 + 5992U);
    t2 = *((char **)t1);
    t1 = (t0 + 13104);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 12064);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0212347615_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0212347615_3212880686_p_0,(void *)work_a_0212347615_3212880686_p_1,(void *)work_a_0212347615_3212880686_p_2,(void *)work_a_0212347615_3212880686_p_3,(void *)work_a_0212347615_3212880686_p_4,(void *)work_a_0212347615_3212880686_p_5,(void *)work_a_0212347615_3212880686_p_6,(void *)work_a_0212347615_3212880686_p_7,(void *)work_a_0212347615_3212880686_p_8,(void *)work_a_0212347615_3212880686_p_9,(void *)work_a_0212347615_3212880686_p_10,(void *)work_a_0212347615_3212880686_p_11,(void *)work_a_0212347615_3212880686_p_12,(void *)work_a_0212347615_3212880686_p_13,(void *)work_a_0212347615_3212880686_p_14,(void *)work_a_0212347615_3212880686_p_15};
	xsi_register_didat("work_a_0212347615_3212880686", "isim/clefia_top_tb_isim_beh.exe.sim/work/a_0212347615_3212880686.didat");
	xsi_register_executes(pe);
}
