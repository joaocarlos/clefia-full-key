/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/joaocarlos/workspace/fpga/clefia-full-key-expansion/sim/tb/clefia_top_tb.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_374109322130769762_503743352(char *, unsigned char );


static void work_a_1925868914_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    int64 t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(102, ng0);

LAB3:    t1 = (t0 + 4528U);
    t2 = *((char **)t1);
    t3 = *((int64 *)t2);
    t4 = (t3 / 2);
    t1 = (t0 + 1032U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t7 = ieee_p_2592010699_sub_374109322130769762_503743352(IEEE_P_2592010699, t6);
    t1 = (t0 + 6448);
    t8 = (t1 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t7;
    xsi_driver_first_trans_delta(t1, 0U, 1, t4);
    t12 = (t0 + 6448);
    xsi_driver_intertial_reject(t12, t4, t4);

LAB2:    t13 = (t0 + 6320);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1925868914_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    int t14;
    unsigned char t15;
    unsigned char t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    char *t20;
    char *t21;

LAB0:    t1 = (t0 + 5752U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(107, ng0);
    t2 = (t0 + 6512);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(108, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 * 5);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(110, ng0);
    t2 = (t0 + 6512);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 6576);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(116, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(117, ng0);
    t2 = (t0 + 6576);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(118, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB12:    xsi_set_current_line(120, ng0);
    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t9 = (255 - 255);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(121, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB18:    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

LAB16:    xsi_set_current_line(122, ng0);
    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t14 = (224 - 1);
    t9 = (255 - t14);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(123, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB22:    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB17:    goto LAB16;

LAB19:    goto LAB17;

LAB20:    xsi_set_current_line(124, ng0);
    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t14 = (192 - 1);
    t9 = (255 - t14);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(125, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB26:    *((char **)t1) = &&LAB27;
    goto LAB1;

LAB21:    goto LAB20;

LAB23:    goto LAB21;

LAB24:    xsi_set_current_line(126, ng0);
    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t14 = (160 - 1);
    t9 = (255 - t14);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(127, ng0);
    t2 = (t0 + 2152U);
    t3 = *((char **)t2);
    t16 = *((unsigned char *)t3);
    t17 = (t16 == (unsigned char)3);
    if (t17 == 1)
        goto LAB31;

LAB32:    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t18 = *((unsigned char *)t4);
    t19 = (t18 == (unsigned char)3);
    t15 = t19;

LAB33:    if (t15 != 0)
        goto LAB28;

LAB30:
LAB29:    xsi_set_current_line(140, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB55:    *((char **)t1) = &&LAB56;
    goto LAB1;

LAB25:    goto LAB24;

LAB27:    goto LAB25;

LAB28:    xsi_set_current_line(128, ng0);
    t2 = (t0 + 4528U);
    t5 = *((char **)t2);
    t7 = *((int64 *)t5);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB36:    *((char **)t1) = &&LAB37;
    goto LAB1;

LAB31:    t15 = (unsigned char)1;
    goto LAB33;

LAB34:    xsi_set_current_line(129, ng0);
    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t14 = (128 - 1);
    t9 = (255 - t14);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(130, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB40:    *((char **)t1) = &&LAB41;
    goto LAB1;

LAB35:    goto LAB34;

LAB37:    goto LAB35;

LAB38:    xsi_set_current_line(131, ng0);
    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t14 = (96 - 1);
    t9 = (255 - t14);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(132, ng0);
    t2 = (t0 + 2312U);
    t3 = *((char **)t2);
    t15 = *((unsigned char *)t3);
    t16 = (t15 == (unsigned char)3);
    if (t16 != 0)
        goto LAB42;

LAB44:
LAB43:    goto LAB29;

LAB39:    goto LAB38;

LAB41:    goto LAB39;

LAB42:    xsi_set_current_line(133, ng0);
    t2 = (t0 + 4528U);
    t4 = *((char **)t2);
    t7 = *((int64 *)t4);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB47:    *((char **)t1) = &&LAB48;
    goto LAB1;

LAB45:    xsi_set_current_line(134, ng0);
    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t14 = (64 - 1);
    t9 = (255 - t14);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(135, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB51:    *((char **)t1) = &&LAB52;
    goto LAB1;

LAB46:    goto LAB45;

LAB48:    goto LAB46;

LAB49:    xsi_set_current_line(136, ng0);
    t2 = (t0 + 4072U);
    t3 = *((char **)t2);
    t14 = (32 - 1);
    t9 = (255 - t14);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    goto LAB43;

LAB50:    goto LAB49;

LAB52:    goto LAB50;

LAB53:    xsi_set_current_line(141, ng0);
    t2 = (t0 + 3272U);
    t3 = *((char **)t2);
    t2 = (t0 + 6640);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(142, ng0);

LAB59:    t2 = (t0 + 6336);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB60;
    goto LAB1;

LAB54:    goto LAB53;

LAB56:    goto LAB54;

LAB57:    t3 = (t0 + 6336);
    *((int *)t3) = 0;
    xsi_set_current_line(143, ng0);
    t2 = (t0 + 6704);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (2 * t7);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t8);

LAB63:    *((char **)t1) = &&LAB64;
    goto LAB1;

LAB58:    t3 = (t0 + 2952U);
    t4 = *((char **)t3);
    t15 = *((unsigned char *)t4);
    t16 = (t15 == (unsigned char)3);
    if (t16 == 1)
        goto LAB57;
    else
        goto LAB59;

LAB60:    goto LAB58;

LAB61:    xsi_set_current_line(145, ng0);
    t2 = (t0 + 6576);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(146, ng0);
    t2 = (t0 + 6768);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(147, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB67:    *((char **)t1) = &&LAB68;
    goto LAB1;

LAB62:    goto LAB61;

LAB64:    goto LAB62;

LAB65:    xsi_set_current_line(148, ng0);
    t2 = (t0 + 6576);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(150, ng0);
    t2 = (t0 + 1992U);
    t3 = *((char **)t2);
    t15 = *((unsigned char *)t3);
    t16 = (t15 == (unsigned char)2);
    if (t16 != 0)
        goto LAB69;

LAB71:    xsi_set_current_line(162, ng0);
    t2 = (t0 + 2152U);
    t3 = *((char **)t2);
    t16 = *((unsigned char *)t3);
    t17 = (t16 == (unsigned char)2);
    if (t17 == 1)
        goto LAB91;

LAB92:    t15 = (unsigned char)0;

LAB93:    if (t15 != 0)
        goto LAB88;

LAB90:    t2 = (t0 + 2152U);
    t3 = *((char **)t2);
    t16 = *((unsigned char *)t3);
    t17 = (t16 == (unsigned char)3);
    if (t17 == 1)
        goto LAB108;

LAB109:    t15 = (unsigned char)0;

LAB110:    if (t15 != 0)
        goto LAB106;

LAB107:    xsi_set_current_line(179, ng0);
    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t9 = (127 - 127);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(180, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB125:    *((char **)t1) = &&LAB126;
    goto LAB1;

LAB66:    goto LAB65;

LAB68:    goto LAB66;

LAB69:    xsi_set_current_line(151, ng0);
    t2 = (t0 + 3432U);
    t4 = *((char **)t2);
    t9 = (127 - 127);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t4 + t11);
    t5 = (t0 + 6640);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    t13 = (t12 + 56U);
    t20 = *((char **)t13);
    memcpy(t20, t2, 32U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(152, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB74:    *((char **)t1) = &&LAB75;
    goto LAB1;

LAB70:    xsi_set_current_line(192, ng0);

LAB141:    t2 = (t0 + 6352);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB142;
    goto LAB1;

LAB72:    xsi_set_current_line(153, ng0);
    t2 = (t0 + 3432U);
    t3 = *((char **)t2);
    t9 = (127 - 95);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(154, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB78:    *((char **)t1) = &&LAB79;
    goto LAB1;

LAB73:    goto LAB72;

LAB75:    goto LAB73;

LAB76:    xsi_set_current_line(155, ng0);
    t2 = (t0 + 3432U);
    t3 = *((char **)t2);
    t9 = (127 - 63);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(156, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB82:    *((char **)t1) = &&LAB83;
    goto LAB1;

LAB77:    goto LAB76;

LAB79:    goto LAB77;

LAB80:    xsi_set_current_line(157, ng0);
    t2 = (t0 + 3432U);
    t3 = *((char **)t2);
    t9 = (127 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB86:    *((char **)t1) = &&LAB87;
    goto LAB1;

LAB81:    goto LAB80;

LAB83:    goto LAB81;

LAB84:    xsi_set_current_line(160, ng0);
    t2 = (t0 + 3272U);
    t3 = *((char **)t2);
    t2 = (t0 + 6640);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast(t2);
    goto LAB70;

LAB85:    goto LAB84;

LAB87:    goto LAB85;

LAB88:    xsi_set_current_line(163, ng0);
    t2 = (t0 + 3592U);
    t5 = *((char **)t2);
    t9 = (127 - 127);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t5 + t11);
    t6 = (t0 + 6640);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    t20 = (t13 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t2, 32U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(164, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB96:    *((char **)t1) = &&LAB97;
    goto LAB1;

LAB89:    xsi_set_current_line(188, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB137:    *((char **)t1) = &&LAB138;
    goto LAB1;

LAB91:    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t18 = *((unsigned char *)t4);
    t19 = (t18 == (unsigned char)2);
    t15 = t19;
    goto LAB93;

LAB94:    xsi_set_current_line(165, ng0);
    t2 = (t0 + 3592U);
    t3 = *((char **)t2);
    t9 = (127 - 95);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(166, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB100:    *((char **)t1) = &&LAB101;
    goto LAB1;

LAB95:    goto LAB94;

LAB97:    goto LAB95;

LAB98:    xsi_set_current_line(167, ng0);
    t2 = (t0 + 3592U);
    t3 = *((char **)t2);
    t9 = (127 - 63);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB104:    *((char **)t1) = &&LAB105;
    goto LAB1;

LAB99:    goto LAB98;

LAB101:    goto LAB99;

LAB102:    xsi_set_current_line(169, ng0);
    t2 = (t0 + 3592U);
    t3 = *((char **)t2);
    t9 = (127 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    goto LAB89;

LAB103:    goto LAB102;

LAB105:    goto LAB103;

LAB106:    xsi_set_current_line(171, ng0);
    t2 = (t0 + 3752U);
    t5 = *((char **)t2);
    t9 = (127 - 127);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t5 + t11);
    t6 = (t0 + 6640);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    t20 = (t13 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t2, 32U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(172, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB113:    *((char **)t1) = &&LAB114;
    goto LAB1;

LAB108:    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t18 = *((unsigned char *)t4);
    t19 = (t18 == (unsigned char)2);
    t15 = t19;
    goto LAB110;

LAB111:    xsi_set_current_line(173, ng0);
    t2 = (t0 + 3752U);
    t3 = *((char **)t2);
    t9 = (127 - 95);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(174, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB117:    *((char **)t1) = &&LAB118;
    goto LAB1;

LAB112:    goto LAB111;

LAB114:    goto LAB112;

LAB115:    xsi_set_current_line(175, ng0);
    t2 = (t0 + 3752U);
    t3 = *((char **)t2);
    t9 = (127 - 63);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(176, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB121:    *((char **)t1) = &&LAB122;
    goto LAB1;

LAB116:    goto LAB115;

LAB118:    goto LAB116;

LAB119:    xsi_set_current_line(177, ng0);
    t2 = (t0 + 3752U);
    t3 = *((char **)t2);
    t9 = (127 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    goto LAB89;

LAB120:    goto LAB119;

LAB122:    goto LAB120;

LAB123:    xsi_set_current_line(181, ng0);
    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t9 = (127 - 95);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(182, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB129:    *((char **)t1) = &&LAB130;
    goto LAB1;

LAB124:    goto LAB123;

LAB126:    goto LAB124;

LAB127:    xsi_set_current_line(183, ng0);
    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t9 = (127 - 63);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(184, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB133:    *((char **)t1) = &&LAB134;
    goto LAB1;

LAB128:    goto LAB127;

LAB130:    goto LAB128;

LAB131:    xsi_set_current_line(185, ng0);
    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t9 = (127 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    goto LAB89;

LAB132:    goto LAB131;

LAB134:    goto LAB132;

LAB135:    xsi_set_current_line(189, ng0);
    t2 = (t0 + 3272U);
    t3 = *((char **)t2);
    t2 = (t0 + 6640);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast(t2);
    goto LAB70;

LAB136:    goto LAB135;

LAB138:    goto LAB136;

LAB139:    t3 = (t0 + 6352);
    *((int *)t3) = 0;
    xsi_set_current_line(194, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (3 * t7);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t8);

LAB145:    *((char **)t1) = &&LAB146;
    goto LAB1;

LAB140:    t3 = (t0 + 3112U);
    t4 = *((char **)t3);
    t15 = *((unsigned char *)t4);
    t16 = (t15 == (unsigned char)3);
    if (t16 == 1)
        goto LAB139;
    else
        goto LAB141;

LAB142:    goto LAB140;

LAB143:    xsi_set_current_line(195, ng0);
    t2 = (t0 + 6576);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(196, ng0);
    t2 = (t0 + 6768);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(197, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB149:    *((char **)t1) = &&LAB150;
    goto LAB1;

LAB144:    goto LAB143;

LAB146:    goto LAB144;

LAB147:    xsi_set_current_line(198, ng0);
    t2 = (t0 + 6576);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(200, ng0);
    t2 = (t0 + 1992U);
    t3 = *((char **)t2);
    t15 = *((unsigned char *)t3);
    t16 = (t15 == (unsigned char)2);
    if (t16 != 0)
        goto LAB151;

LAB153:    xsi_set_current_line(212, ng0);
    t2 = (t0 + 2152U);
    t3 = *((char **)t2);
    t16 = *((unsigned char *)t3);
    t17 = (t16 == (unsigned char)2);
    if (t17 == 1)
        goto LAB173;

LAB174:    t15 = (unsigned char)0;

LAB175:    if (t15 != 0)
        goto LAB170;

LAB172:    t2 = (t0 + 2152U);
    t3 = *((char **)t2);
    t16 = *((unsigned char *)t3);
    t17 = (t16 == (unsigned char)3);
    if (t17 == 1)
        goto LAB190;

LAB191:    t15 = (unsigned char)0;

LAB192:    if (t15 != 0)
        goto LAB188;

LAB189:    xsi_set_current_line(229, ng0);
    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t9 = (127 - 127);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(230, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB207:    *((char **)t1) = &&LAB208;
    goto LAB1;

LAB148:    goto LAB147;

LAB150:    goto LAB148;

LAB151:    xsi_set_current_line(201, ng0);
    t2 = (t0 + 3432U);
    t4 = *((char **)t2);
    t9 = (127 - 127);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t4 + t11);
    t5 = (t0 + 6640);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    t13 = (t12 + 56U);
    t20 = *((char **)t13);
    memcpy(t20, t2, 32U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(202, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB156:    *((char **)t1) = &&LAB157;
    goto LAB1;

LAB152:    xsi_set_current_line(242, ng0);

LAB223:    t2 = (t0 + 6368);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB224;
    goto LAB1;

LAB154:    xsi_set_current_line(203, ng0);
    t2 = (t0 + 3432U);
    t3 = *((char **)t2);
    t9 = (127 - 95);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(204, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB160:    *((char **)t1) = &&LAB161;
    goto LAB1;

LAB155:    goto LAB154;

LAB157:    goto LAB155;

LAB158:    xsi_set_current_line(205, ng0);
    t2 = (t0 + 3432U);
    t3 = *((char **)t2);
    t9 = (127 - 63);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(206, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB164:    *((char **)t1) = &&LAB165;
    goto LAB1;

LAB159:    goto LAB158;

LAB161:    goto LAB159;

LAB162:    xsi_set_current_line(207, ng0);
    t2 = (t0 + 3432U);
    t3 = *((char **)t2);
    t9 = (127 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(209, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB168:    *((char **)t1) = &&LAB169;
    goto LAB1;

LAB163:    goto LAB162;

LAB165:    goto LAB163;

LAB166:    xsi_set_current_line(210, ng0);
    t2 = (t0 + 3272U);
    t3 = *((char **)t2);
    t2 = (t0 + 6640);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast(t2);
    goto LAB152;

LAB167:    goto LAB166;

LAB169:    goto LAB167;

LAB170:    xsi_set_current_line(213, ng0);
    t2 = (t0 + 3592U);
    t5 = *((char **)t2);
    t9 = (127 - 127);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t5 + t11);
    t6 = (t0 + 6640);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    t20 = (t13 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t2, 32U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(214, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB178:    *((char **)t1) = &&LAB179;
    goto LAB1;

LAB171:    xsi_set_current_line(238, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB219:    *((char **)t1) = &&LAB220;
    goto LAB1;

LAB173:    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t18 = *((unsigned char *)t4);
    t19 = (t18 == (unsigned char)2);
    t15 = t19;
    goto LAB175;

LAB176:    xsi_set_current_line(215, ng0);
    t2 = (t0 + 3592U);
    t3 = *((char **)t2);
    t9 = (127 - 95);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(216, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB182:    *((char **)t1) = &&LAB183;
    goto LAB1;

LAB177:    goto LAB176;

LAB179:    goto LAB177;

LAB180:    xsi_set_current_line(217, ng0);
    t2 = (t0 + 3592U);
    t3 = *((char **)t2);
    t9 = (127 - 63);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(218, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB186:    *((char **)t1) = &&LAB187;
    goto LAB1;

LAB181:    goto LAB180;

LAB183:    goto LAB181;

LAB184:    xsi_set_current_line(219, ng0);
    t2 = (t0 + 3592U);
    t3 = *((char **)t2);
    t9 = (127 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    goto LAB171;

LAB185:    goto LAB184;

LAB187:    goto LAB185;

LAB188:    xsi_set_current_line(221, ng0);
    t2 = (t0 + 3752U);
    t5 = *((char **)t2);
    t9 = (127 - 127);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t5 + t11);
    t6 = (t0 + 6640);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    t20 = (t13 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t2, 32U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(222, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB195:    *((char **)t1) = &&LAB196;
    goto LAB1;

LAB190:    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t18 = *((unsigned char *)t4);
    t19 = (t18 == (unsigned char)2);
    t15 = t19;
    goto LAB192;

LAB193:    xsi_set_current_line(223, ng0);
    t2 = (t0 + 3752U);
    t3 = *((char **)t2);
    t9 = (127 - 95);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(224, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB199:    *((char **)t1) = &&LAB200;
    goto LAB1;

LAB194:    goto LAB193;

LAB196:    goto LAB194;

LAB197:    xsi_set_current_line(225, ng0);
    t2 = (t0 + 3752U);
    t3 = *((char **)t2);
    t9 = (127 - 63);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(226, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB203:    *((char **)t1) = &&LAB204;
    goto LAB1;

LAB198:    goto LAB197;

LAB200:    goto LAB198;

LAB201:    xsi_set_current_line(227, ng0);
    t2 = (t0 + 3752U);
    t3 = *((char **)t2);
    t9 = (127 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    goto LAB171;

LAB202:    goto LAB201;

LAB204:    goto LAB202;

LAB205:    xsi_set_current_line(231, ng0);
    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t9 = (127 - 95);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(232, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB211:    *((char **)t1) = &&LAB212;
    goto LAB1;

LAB206:    goto LAB205;

LAB208:    goto LAB206;

LAB209:    xsi_set_current_line(233, ng0);
    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t9 = (127 - 63);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(234, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t7);

LAB215:    *((char **)t1) = &&LAB216;
    goto LAB1;

LAB210:    goto LAB209;

LAB212:    goto LAB210;

LAB213:    xsi_set_current_line(235, ng0);
    t2 = (t0 + 3912U);
    t3 = *((char **)t2);
    t9 = (127 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t2 = (t3 + t11);
    t4 = (t0 + 6640);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    goto LAB171;

LAB214:    goto LAB213;

LAB216:    goto LAB214;

LAB217:    xsi_set_current_line(239, ng0);
    t2 = (t0 + 3272U);
    t3 = *((char **)t2);
    t2 = (t0 + 6640);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast(t2);
    goto LAB152;

LAB218:    goto LAB217;

LAB220:    goto LAB218;

LAB221:    t3 = (t0 + 6368);
    *((int *)t3) = 0;
    xsi_set_current_line(243, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 * 5);
    t2 = (t0 + 5560);
    xsi_process_wait(t2, t8);

LAB227:    *((char **)t1) = &&LAB228;
    goto LAB1;

LAB222:    t3 = (t0 + 3112U);
    t4 = *((char **)t3);
    t15 = *((unsigned char *)t4);
    t16 = (t15 == (unsigned char)3);
    if (t16 == 1)
        goto LAB221;
    else
        goto LAB223;

LAB224:    goto LAB222;

LAB225:    xsi_set_current_line(244, ng0);
    t2 = (t0 + 12368);
    xsi_report(t2, 17U, (unsigned char)3);
    goto LAB2;

LAB226:    goto LAB225;

LAB228:    goto LAB226;

}

static void work_a_1925868914_2372691052_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    char *t6;
    int t7;
    int t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    int64 t14;

LAB0:    t1 = (t0 + 6000U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(251, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 != 0)
        goto LAB4;

LAB6:    t2 = (t0 + 4232U);
    t3 = *((char **)t2);
    t7 = *((int *)t3);
    t4 = (t7 != 0);
    if (t4 != 0)
        goto LAB7;

LAB8:
LAB5:    xsi_set_current_line(256, ng0);
    t2 = (t0 + 4528U);
    t3 = *((char **)t2);
    t14 = *((int64 *)t3);
    t2 = (t0 + 5808);
    xsi_process_wait(t2, t14);

LAB11:    *((char **)t1) = &&LAB12;

LAB1:    return;
LAB4:    xsi_set_current_line(252, ng0);
    t2 = (t0 + 4232U);
    t6 = *((char **)t2);
    t7 = *((int *)t6);
    t8 = (t7 + 1);
    t2 = (t0 + 6832);
    t9 = (t2 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((int *)t12) = t8;
    xsi_driver_first_trans_fast(t2);
    goto LAB5;

LAB7:    xsi_set_current_line(254, ng0);
    t2 = (t0 + 4232U);
    t6 = *((char **)t2);
    t8 = *((int *)t6);
    t13 = (t8 + 1);
    t2 = (t0 + 6832);
    t9 = (t2 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((int *)t12) = t13;
    xsi_driver_first_trans_fast(t2);
    goto LAB5;

LAB9:    goto LAB2;

LAB10:    goto LAB9;

LAB12:    goto LAB10;

}


extern void work_a_1925868914_2372691052_init()
{
	static char *pe[] = {(void *)work_a_1925868914_2372691052_p_0,(void *)work_a_1925868914_2372691052_p_1,(void *)work_a_1925868914_2372691052_p_2};
	xsi_register_didat("work_a_1925868914_2372691052", "isim/clefia_top_tb_isim_beh.exe.sim/work/a_1925868914_2372691052.didat");
	xsi_register_executes(pe);
}
